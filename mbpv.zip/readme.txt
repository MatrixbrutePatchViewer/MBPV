Matrixbrute Patch Viewer (MBPV) v0.5.1 2022-03-14
=================================================

Important notice:
=================
By using this software you accept the following:

- This software is written for my own use, it's not associated with Arturia in any way. This is an early version, but most functionality is in place.
- It is not to be considered as "professionally released software", and no guarantee in any way is given. Use at your own risk.
- It is shared for free in the hope that it can be useful for other Matrixbrute owners. You're not allowed to sell this software or charge for it.
- The program will only READ the Matrixbrute files exported by MCC (no editing/writing is possible during normal operation).
- It can't connect to the Matrixbrute directly.
- All data formats are decoded by users (not based on any Arturia documentation), so info shown in a preset/patch might be inaccurate, missing or wrong – and might stop working after a firmware update.

See manual for installation details (in short: needs java 11+). Open runMBPV.bat for details about the startup options.

See github for more information / updated versions and manual.

Github: https://github.com/MatrixbrutePatchViewer/MBPV
Contact: matrixbrutepv@hotmail.com

Changes:
2022-03-12: v0.5: Added export to images and html
2022-03-14: v0.5.1: Split menu bar over 2 lines
